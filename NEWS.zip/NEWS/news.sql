-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2017 at 04:16 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news`
--

-- --------------------------------------------------------

--
-- Table structure for table `credentials`
--

CREATE TABLE `credentials` (
  `id` int(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `credentials`
--

INSERT INTO `credentials` (`id`, `email`, `password`, `name`, `type`) VALUES
(1, 'reporter@gmail.com', '12321', 'John Snow', 'reporter'),
(2, 'mod@gmail.com', '12321', 'Maddy ', 'moderator'),
(0, 'admin@gmail.com', '12321', 'admin', 'admin'),
(3, 'admin@gmail.com', '12321', 'admin', 'admin'),
(0, 'arvi@@gmail.com', '12321', 'arv', 'police'),
(0, 'amb@gmail.com', '12321', 'Ambulance', 'ambulance');

-- --------------------------------------------------------

--
-- Table structure for table `public_news`
--

CREATE TABLE `public_news` (
  `nid` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `category` varchar(200) NOT NULL,
  `city` text NOT NULL,
  `street` text NOT NULL,
  `image` text NOT NULL,
  `video` text NOT NULL,
  `document` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `public_news`
--

INSERT INTO `public_news` (`nid`, `id`, `title`, `description`, `category`, `city`, `street`, `image`, `video`, `document`, `status`, `date`) VALUES
(2, 1, 'Hindustan Times Belt and Road forum: Chinese President Xi pledges billions for new Silk Road, \'snubs\' absentee India', 'Hindustan Times Belt and Road forum: Chinese President Xi pledges billions for new Silk Road, \'snubs\' absentee IndiaHindustan Times Belt and Road forum: Chinese President Xi pledges billions for new Silk Road, \'snubs\' absentee India', 'politics', 'bangalore', 'yelahanka', '../media_files/20-zoopworld.jpg', '../media_files/My Movie.mp4', '../media_files/My Movie.mp4', 'verified', '2017-05-15 04:15:15'),
(18, 1, 'hi', 'Hsjssjsbs DD d fdusisis ', 'Entertainment', 'Get City', 'Get location', '    \r\n\r\n../media_files/IMG_20170515_023953.jpg', '', '', 'not_verified', '2017-05-15 04:24:16'),
(19, 1, 'Hindustan Times Belt and Road forum: Chinese President Xi pledges billions for new Silk Road, \'snubs\' absentee India', 'Hindustan Times Belt and Road forum: Chinese President Xi pledges billions for new Silk Road, \'snubs\' absentee IndiaHindustan Times Belt and Road forum: Chinese President Xi pledges billions for new Silk Road, \'snubs\' absentee India', 'politics', 'bangalore', 'yelahanka', '../media_files/20-zoopworld.jpg', '../media_files/My Movie.mp4', '../media_files/My Movie.mp4', 'verified', '2017-06-15 04:15:15'),
(20, 8, 'Gani maharaj ki Dhulhania', 'fan show some more information please login information confidential information belonging to get back to work with your company that I could be a problem with you and your team and your family and your wife and daughter and I would love for your time in my case you have to get back on track record for your email', 'Politics', 'Yelahanka New Town, Bengaluru, Karnataka, India', '1134-1141, 16th B Cross Rd, LIG 3rd Stage, Yelahanka Satellite Town, Yelahanka, Bengaluru, Karnataka 560064, India', '    \r\n\r\n../media_files/TMPDOODLE1495286336563.jpg', '    \r\n\r\n../media_files/TMPDOODLE1495286359237.jpg', '    \r\n\r\n../media_files/proprieta-CSS.pdf', 'not_verified', '2017-05-20 13:21:17'),
(21, 8, 'Gani maharaj ki Dhulhania jai', 'fan show some more information please login information confidential information belonging to get back to work with your company that I could be a problem with you and your team and your family and your wife and daughter and I would love for your time in my case you have to get back on track record for your email', 'Politics', 'Yelahanka New Town, Bengaluru, Karnataka, India', '1134-1141, 16th B Cross Rd, LIG 3rd Stage, Yelahanka Satellite Town, Yelahanka, Bengaluru, Karnataka 560064, India', '    \r\n\r\n../media_files/TMPDOODLE1495286336563.jpg', '    \r\n\r\n../media_files/TMPDOODLE1495286359237.jpg', '    \r\n\r\n../media_files/proprieta-CSS.pdf', 'verified', '2017-05-20 13:21:38'),
(22, 8, 'jnkj', 'joijoijo', 'Business', 'Get City', 'Get location', '', '', '', 'fake', '2017-05-22 10:32:32'),
(23, 9, 'Rljit', 'Project submission on 30', 'National', 'Get City', 'Get location', '', '', '    \r\n\r\n../media_files/IMG-20170528-WA0025.jpg', 'fake', '2017-05-29 10:38:45'),
(24, 9, 'Rljit', 'Project submission on 30', 'National', 'Get City', 'Get location', '', '', '    \r\n\r\n../media_files/IMG-20170528-WA0025.jpg', 'verified', '2017-05-29 10:38:46'),
(25, 12, 'Breaking news', 'News on arvind', 'Entertainment', 'Get City', 'Get location', '    \r\n\r\n../media_files/International-surfing_&_d833732a-1c73-4fcb-801a-03ab142ba05c.jpg', '', '', 'verified', '2017-05-30 09:48:19'),
(26, 12, 'Breaking news', 'News on arvind', 'Entertainment', 'Get City', 'Get location', '    \r\n\r\n../media_files/International-surfing_&_d833732a-1c73-4fcb-801a-03ab142ba05c.jpg', '', '', 'not_verified', '2017-05-30 09:48:28'),
(27, 16, 'aaaa', 'yyyyyyy', 'National', 'Get City', 'Get location', '', '', '', 'verified', '2017-05-30 12:01:21'),
(28, 18, 'Job fair', 'All the last year student has a brilliant opportunities to get placed in a big company. ', 'National', 'Get City', 'Get location', '', '', '', 'not_verified', '2017-05-31 20:08:02');

-- --------------------------------------------------------

--
-- Table structure for table `public_news_ambulancee`
--

CREATE TABLE `public_news_ambulancee` (
  `nid` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `location` text NOT NULL,
  `image` text NOT NULL,
  `video` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `public_news_ambulancee`
--

INSERT INTO `public_news_ambulancee` (`nid`, `id`, `title`, `description`, `location`, `image`, `video`, `status`, `date`) VALUES
(1, 12, 'Hshs', 'Jdhdjs', 'Yelahanka', '    \r\n\r\n../media_files/Screenshot_2017-05-29-16-08-31-170_com.instagram.android.png', '', 'not_serviced', '2017-05-29 14:52:42');

-- --------------------------------------------------------

--
-- Table structure for table `public_news_police`
--

CREATE TABLE `public_news_police` (
  `nid` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `location` text NOT NULL,
  `image` text NOT NULL,
  `video` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `public_news_police`
--

INSERT INTO `public_news_police` (`nid`, `id`, `title`, `description`, `location`, `image`, `video`, `status`, `date`) VALUES
(1, 12, 'Something', 'Xyz', 'Db', '', '', 'none', '2017-05-29 14:51:57'),
(2, 12, 'Xxx', 'Yyy', 'Dbpur', '', '', 'none', '2017-05-29 14:51:57'),
(3, 9, 'f6rfr6', 'hhhhhhhhhhhhh', '', '', '', 'none', '2017-05-29 14:51:57'),
(4, 12, 'aaww', 'ppyyrraa', '', '', '', 'none', '2017-05-30 04:25:38');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `reporter_id` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `occupation` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `aadhar_id` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `verification_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reporter_id`, `name`, `email`, `mobile`, `password`, `occupation`, `address`, `gender`, `aadhar_id`, `state`, `verification_status`) VALUES
(4, 'babu', 'babud@gmail.com', '2147483647', 'BabauS44454', 'Developer', 'bangalore', 'male', 'AID41407', 'Karnataka', 'verified'),
(5, 'ganesh', 'ramugaikwad12@gmail.com', '2147483647', 'qwerty', 'it', '2345,mig 3rd stage,16th b cross,near agarwal eye hospital\nyelahanka newtown', 'male', 'abc1245454', 'Karnataka', 'verified'),
(12, 'Sharath', 'saisharath@gmail.com', '2147483647', 'jyoram@4488', 'Student', 'Bangalore yelahanka newtown', 'male', '123456789056', 'Karnataka', 'verified'),
(13, 'karthik', 'karthikshvs@gmail.com', '2147483647', 'beast', 'student', 'db pur', 'male', '235646316331', 'karnataka', 'not_verified'),
(14, 'Mahendran', 'mah@gmail.com', '9880806099', '123456', 'HR', 'Andjdb', 'male', '12345677890727', 'Karnataka', 'not_verified'),
(16, 'gaana', 'gaana@gmail.com', '9742507376', '123456', 'professor', 'yfyfhjf', 'female', '142587698', 'karnataka', 'verified'),
(17, 'srinivasa', 'vasa2856@gmail.com', '9066177291', 'Srinivasa!123', 'Student', 'Agrahara prison', 'male', '420', 'Karnataka', 'not_verified'),
(18, 'Raj', 'raj@gmail.com', '8123881587', 'raj', 'student', 'Bangalore', 'male', '444456789867', 'karnataka', 'verified');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `public_news`
--
ALTER TABLE `public_news`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `public_news_ambulancee`
--
ALTER TABLE `public_news_ambulancee`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `public_news_police`
--
ALTER TABLE `public_news_police`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD UNIQUE KEY `reporter_id` (`reporter_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `public_news`
--
ALTER TABLE `public_news`
  MODIFY `nid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `public_news_ambulancee`
--
ALTER TABLE `public_news_ambulancee`
  MODIFY `nid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `public_news_police`
--
ALTER TABLE `public_news_police`
  MODIFY `nid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `reporter_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
